# saber_pkm > 2024-07-25 8:31am
https://universe.roboflow.com/pkmsaber/saber_pkm

Provided by a Roboflow user
License: CC BY 4.0

